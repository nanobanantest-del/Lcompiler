# 🔨 Llogin Plugin Compiler — Web Service

ZIP upload karo → JAR download karo. Bas itna.

---

## ⚡ Quick Start (Docker — Recommended)

```bash
# 1. Repository clone karo (ya ZIP extract karo)
cd llogin-compiler

# 2. Build + Start karo
docker-compose up --build

# 3. Browser mein kholo
http://localhost:3000
```

Pehli baar Docker image build hogi (~3-5 min) — Gradle + Java download hoga.
Baad mein `docker-compose up` se sirf 5-10 second lagenge.

---

## 🌐 Internet Pe Deploy Karna (VPS/Cloud)

### Option A — Same VPS pe run karo

```bash
# VPS pe ye commands chalaao
git clone <your-repo> llogin-compiler
cd llogin-compiler
docker-compose up -d --build

# Port 3000 firewall mein open karo
ufw allow 3000
```

Phir access karo: `http://YOUR_VPS_IP:3000`

---

### Option B — Nginx reverse proxy (domain ke saath)

```nginx
# /etc/nginx/sites-available/compiler.conf

server {
    listen 80;
    server_name compiler.yourdomain.com;

    # File upload size limit
    client_max_body_size 55M;

    location / {
        proxy_pass         http://127.0.0.1:3000;
        proxy_http_version 1.1;
        proxy_set_header   Host              $host;
        proxy_set_header   X-Real-IP         $remote_addr;
        proxy_set_header   X-Forwarded-For   $proxy_add_x_forwarded_for;
        proxy_read_timeout 360s;
        proxy_send_timeout 360s;
    }
}
```

```bash
ln -s /etc/nginx/sites-available/compiler.conf /etc/nginx/sites-enabled/
nginx -t && systemctl reload nginx
```

SSL ke liye:
```bash
certbot --nginx -d compiler.yourdomain.com
```

---

### Option C — Bina Docker ke (Local Node.js)

```bash
# Requirements:
#   - Java 21 (java -version check karo)
#   - Gradle 8.5 (gradle -version check karo)
#   - Node.js 20+ (node -version check karo)

cd llogin-compiler/backend
npm install
node server.js
```

---

## 🔧 Environment Variables

`docker-compose.yml` mein change karo:

| Variable | Default | Description |
|---|---|---|
| `PORT` | `3000` | Web server port |
| `MAX_FILE_SIZE_MB` | `50` | Max ZIP upload size |
| `BUILD_TIMEOUT_SECONDS` | `300` | Gradle timeout (5 min) |
| `GRADLE_CMD` | `gradle` | Gradle executable path |

---

## 📁 Project Structure

```
llogin-compiler/
├── docker-compose.yml      ← Start karne ke liye
├── Dockerfile              ← Java 21 + Node.js image
├── backend/
│   ├── server.js           ← Express API server
│   ├── package.json
│   ├── public/
│   │   └── index.html      ← Web UI
│   └── warmup/             ← Docker Gradle cache warmup
│       ├── build.gradle
│       └── settings.gradle
```

---

## 🔒 Security Notes

- Uploaded ZIPs auto-delete hoti hain build ke baad
- Compiled JARs 1 ghante baad auto-delete hote hain
- Rate limit: **10 builds per IP per hour**
- Sirf `.zip` files accept hoti hain
- Max file size: 50MB

---

## ❓ Troubleshooting

**"Docker not found"**
```bash
# Ubuntu/Debian
curl -fsSL https://get.docker.com | sh
sudo usermod -aG docker $USER
newgrp docker
```

**Build timeout ho raha hai**
```yaml
# docker-compose.yml mein badlo:
environment:
  - BUILD_TIMEOUT_SECONDS=600  # 10 minutes
```

**Port already in use**
```yaml
# docker-compose.yml mein port badlo:
ports:
  - "8080:3000"   # 8080 pe access hoga
```

**Gradle dependencies download nahi ho rahi**
> Server ko internet access chahiye. Proxy ke peeche ho toh Gradle proxy config karo.

---

## 💡 Kaise Kaam Karta Hai

```
User uploads ZIP
       │
       ▼
  Express server receives file (multer)
       │
       ▼
  Unique Job ID generate hota hai
       │
       ▼
  ZIP extract hoti hai /uploads/<jobId>/
       │
       ▼
  build.gradle.kts dhundha jaata hai
       │
       ▼
  ./gradlew shadowJar run hota hai
       │
       ▼
  build/libs/*.jar copy hoti hai /output/
       │
       ▼
  Frontend poll karta hai /api/status/:jobId
       │
       ▼
  Download link milta hai /api/download/:jobId
       │
       ▼
  1 ghante baad files auto-delete
```
