'use strict';

const express    = require('express');
const multer     = require('multer');
const cors       = require('cors');
const rateLimit  = require('express-rate-limit');
const path       = require('path');
const fs         = require('fs');
const fsp        = require('fs').promises;
const { exec, spawn } = require('child_process');
const { v4: uuidv4 }  = require('uuid');

// ─── Config ───────────────────────────────────────────────────
const PORT             = process.env.PORT || 3000;
const MAX_FILE_MB      = parseInt(process.env.MAX_FILE_SIZE_MB  || '50');
const BUILD_TIMEOUT_MS = parseInt(process.env.BUILD_TIMEOUT_SECONDS || '300') * 1000;
const UPLOAD_DIR       = path.join(__dirname, 'uploads');
const OUTPUT_DIR       = path.join(__dirname, 'output');
const FRONTEND_DIR     = path.join(__dirname, 'public');
const GRADLE_CMD       = process.env.GRADLE_CMD || 'gradle';

[UPLOAD_DIR, OUTPUT_DIR, FRONTEND_DIR].forEach(d => fs.mkdirSync(d, { recursive: true }));

// ─── Job Store ────────────────────────────────────────────────
const jobs = new Map();

setInterval(() => {
  const cutoff = Date.now() - 3600_000;
  for (const [id, job] of jobs.entries()) {
    if (job.startedAt < cutoff) {
      if (job.workDir) fs.rmSync(job.workDir, { recursive: true, force: true });
      if (job.jarPath) fs.rmSync(job.jarPath, { force: true });
      jobs.delete(id);
    }
  }
}, 600_000);

// ─── Express ──────────────────────────────────────────────────
const app = express();

// FIX 1: Trust proxy — required for Codespaces / any reverse proxy
app.set('trust proxy', 1);

app.use(cors());
app.use(express.json());

const buildLimiter = rateLimit({
  windowMs: 3600_000,
  max: 20,
  standardHeaders: true,
  legacyHeaders: false,
  // FIX 2: Skip rate limit for local/Codespaces forwarded IPs
  skip: (req) => {
    const ip = req.ip || '';
    return ip === '::1' || ip === '127.0.0.1' || ip.startsWith('10.') || ip.startsWith('172.');
  }
});

app.use(express.static(FRONTEND_DIR));

// ─── Multer ───────────────────────────────────────────────────
const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, UPLOAD_DIR),
  filename:    (req, file, cb) => cb(null, `${uuidv4()}_${file.originalname}`)
});

const upload = multer({
  storage,
  limits: { fileSize: MAX_FILE_MB * 1024 * 1024 },
  fileFilter: (req, file, cb) => {
    if (!file.originalname.toLowerCase().endsWith('.zip'))
      return cb(new Error('Only .zip files are allowed'));
    cb(null, true);
  }
});

// ─── Routes ───────────────────────────────────────────────────
app.get('/health', (req, res) =>
  res.json({ status: 'ok', jobs: jobs.size, uptime: process.uptime() }));

app.post('/api/build', buildLimiter, upload.single('plugin'), async (req, res) => {
  if (!req.file) return res.status(400).json({ error: 'No ZIP file uploaded.' });

  const jobId   = uuidv4();
  const workDir = path.join(UPLOAD_DIR, jobId);
  const zipPath = req.file.path;

  jobs.set(jobId, {
    status: 'extracting', log: [], jarPath: null,
    workDir, startedAt: Date.now(), finishedAt: null,
    filename: req.file.originalname
  });

  res.json({ jobId });
  runBuild(jobId, zipPath, workDir).catch(() => {});
});

app.get('/api/status/:jobId', (req, res) => {
  const job = jobs.get(req.params.jobId);
  if (!job) return res.status(404).json({ error: 'Job not found.' });
  res.json({
    status:      job.status,
    log:         job.log,
    filename:    job.filename,
    startedAt:   job.startedAt,
    finishedAt:  job.finishedAt,
    downloadUrl: job.jarPath ? `/api/download/${req.params.jobId}` : null
  });
});

app.get('/api/download/:jobId', (req, res) => {
  const job = jobs.get(req.params.jobId);
  if (!job || !job.jarPath)       return res.status(404).json({ error: 'JAR not available.' });
  if (!fs.existsSync(job.jarPath)) return res.status(410).json({ error: 'JAR file expired.' });
  const jarName = path.basename(job.jarPath);
  res.setHeader('Content-Disposition', `attachment; filename="${jarName}"`);
  res.setHeader('Content-Type', 'application/java-archive');
  fs.createReadStream(job.jarPath).pipe(res);
});

// ─── Build Pipeline ───────────────────────────────────────────
async function runBuild(jobId, zipPath, workDir) {
  const job = jobs.get(jobId);
  const log = (msg) => { console.log(`[${jobId.slice(0,8)}] ${msg}`); job.log.push(msg); };

  try {
    // Step 1: Extract
    log('📦 Extracting ZIP archive...');
    await extractZip(zipPath, workDir);
    log('✓ Extraction complete.');

    // Step 2: Find project root
    const projectRoot = await findProjectRoot(workDir);
    if (!projectRoot) throw new Error('build.gradle.kts / build.gradle not found in ZIP.');
    log(`✓ Project root: ${path.relative(workDir, projectRoot) || '.'}`);

    const buildFile = fs.existsSync(path.join(projectRoot, 'build.gradle.kts'))
        ? 'build.gradle.kts' : 'build.gradle';
    log(`✓ Build file: ${buildFile}`);

    // Step 3: Generate Gradle wrapper if missing
    const gradlewPath = path.join(projectRoot, 'gradlew');
    if (!fs.existsSync(gradlewPath)) {
      log('⚙ Generating Gradle wrapper...');
      // FIX 3: use exec with large buffer, increase timeout for wrapper gen
      await runShell(
        `${GRADLE_CMD} wrapper --gradle-version 8.5 --distribution-type bin --no-daemon`,
        projectRoot, log, 120_000
      );
      log('✓ Wrapper generated.');
    }

    // FIX 4: Ensure gradlew is executable
    await fsp.chmod(gradlewPath, 0o755);

    // Step 4: Gradle build
    job.status = 'building';
    log('');
    log('🔨 Starting Gradle build...');
    log('─'.repeat(48));

    await runGradle(projectRoot, log);

    log('─'.repeat(48));
    log('');

    // Step 5: Find JAR
    const jarFile = await findJar(projectRoot);
    if (!jarFile) throw new Error('No JAR found in build/libs/ after successful build.');
    log(`✓ JAR: ${path.basename(jarFile)}`);

    // Step 6: Copy to output
    const outputJar = path.join(OUTPUT_DIR, `${jobId}_${path.basename(jarFile)}`);
    await fsp.copyFile(jarFile, outputJar);

    // Step 7: Cleanup
    await fsp.rm(zipPath,  { force: true });
    await fsp.rm(workDir,  { recursive: true, force: true });

    job.jarPath    = outputJar;
    job.status     = 'success';
    job.finishedAt = Date.now();
    const elapsed  = ((job.finishedAt - job.startedAt) / 1000).toFixed(1);
    log('');
    log(`✅ Build successful in ${elapsed}s!`);

  } catch (err) {
    job.status     = 'failed';
    job.finishedAt = Date.now();
    log('');
    log(`❌ Build failed: ${err.message}`);
    await fsp.rm(zipPath, { force: true }).catch(() => {});
    await fsp.rm(workDir, { recursive: true, force: true }).catch(() => {});
  }
}

// ─── Helpers ──────────────────────────────────────────────────
function extractZip(zipPath, destDir) {
  return new Promise((resolve, reject) => {
    fs.mkdirSync(destDir, { recursive: true });
    exec(`unzip -q "${zipPath}" -d "${destDir}"`,
      { maxBuffer: 10 * 1024 * 1024 },
      (err, _stdout, stderr) => {
        if (err) reject(new Error(`Extraction failed: ${stderr || err.message}`));
        else resolve();
      });
  });
}

async function findProjectRoot(baseDir) {
  const queue = [baseDir];
  while (queue.length > 0) {
    const dir = queue.shift();
    if (fs.existsSync(path.join(dir, 'build.gradle.kts')) ||
        fs.existsSync(path.join(dir, 'build.gradle'))) return dir;
    if (dir.split(path.sep).length - baseDir.split(path.sep).length < 4) {
      try {
        const entries = await fsp.readdir(dir, { withFileTypes: true });
        for (const e of entries) {
          if (e.isDirectory() && e.name !== 'node_modules' && e.name !== '.git')
            queue.push(path.join(dir, e.name));
        }
      } catch {}
    }
  }
  return null;
}

// FIX 5: runShell with configurable timeout + large buffer
function runShell(cmd, cwd, log, timeout = 60_000) {
  return new Promise((resolve, reject) => {
    exec(cmd, { cwd, timeout, maxBuffer: 20 * 1024 * 1024 },
      (err, stdout, stderr) => {
        if (stdout) stdout.split('\n').filter(Boolean).forEach(l => log(l));
        if (stderr) stderr.split('\n').filter(Boolean).forEach(l => log(`[WARN] ${l}`));
        if (err) reject(new Error(err.message));
        else resolve();
      });
  });
}

function runGradle(projectRoot, log) {
  return new Promise((resolve, reject) => {
    const gradlew = path.join(projectRoot, 'gradlew');

    // FIX 6: Reduced JVM memory so Codespaces free tier doesn't OOM-kill
    const args = [
      'shadowJar',
      '--no-daemon',
      '--stacktrace',
      '--warning-mode=none',
      '-Dorg.gradle.jvmargs=-Xmx768m -Xms256m',
      '-Dorg.gradle.parallel=false',
      '-Dorg.gradle.caching=false',
    ];

    // Detect Java home
    const javaHome = process.env.JAVA_HOME
        || '/opt/java/openjdk'
        || '/usr/lib/jvm/temurin-21-amd64';

    const proc = spawn(gradlew, args, {
      cwd: projectRoot,
      env: { ...process.env, JAVA_HOME: javaHome },
      // FIX 7: kill process group on timeout
      detached: false,
    });

    const importantKeywords = [
      '> Task', 'Task :', 'BUILD', 'FAILURE', 'SUCCESS', 'Exception',
      'error:', 'Could not', 'e:', ': error', 'Compiling', '> Configure',
      'Deprecated', 'WARNING', 'warning:', '✓', '❌', '─'
    ];

    let outBuf = '', errBuf = '';

    const flush = (buf, prefix = '') => {
      const lines = buf.split('\n');
      const remaining = lines.pop() ?? '';
      lines.forEach(line => {
        const t = line.trim();
        if (!t) return;
        if (importantKeywords.some(k => t.includes(k)) || t.startsWith('>') || t.startsWith(':'))
          log(prefix + t);
      });
      return remaining;
    };

    proc.stdout.on('data', d => { outBuf += d.toString(); outBuf = flush(outBuf); });
    proc.stderr.on('data', d => { errBuf += d.toString(); errBuf = flush(errBuf, '[ERR] '); });

    const timer = setTimeout(() => {
      proc.kill('SIGKILL');
      reject(new Error(`Build timed out after ${BUILD_TIMEOUT_MS / 1000}s`));
    }, BUILD_TIMEOUT_MS);

    // FIX 8: Handle null exit code (signal kill) properly
    proc.on('close', (code, signal) => {
      clearTimeout(timer);
      if (outBuf.trim()) log(outBuf.trim());
      if (errBuf.trim()) log('[ERR] ' + errBuf.trim());

      if (code === 0) {
        resolve();
      } else if (signal) {
        reject(new Error(
          `Gradle process was killed by signal ${signal}. ` +
          `This usually means out-of-memory. Try reducing dependencies.`
        ));
      } else {
        reject(new Error(
          `Gradle exited with code ${code ?? 'unknown'}. Check log above.`
        ));
      }
    });

    proc.on('error', err => {
      clearTimeout(timer);
      reject(new Error(`Failed to start Gradle: ${err.message}`));
    });
  });
}

async function findJar(projectRoot) {
  const libsDir = path.join(projectRoot, 'build', 'libs');
  if (!fs.existsSync(libsDir)) return null;
  const files = await fsp.readdir(libsDir);
  const jars = files
    .filter(f => f.endsWith('.jar') && !f.endsWith('-plain.jar') && !f.endsWith('-sources.jar'))
    .map(f => path.join(libsDir, f));
  return jars.length > 0 ? jars[0] : null;
}

// ─── Start ────────────────────────────────────────────────────
app.listen(PORT, () => {
  console.log(`\n🚀 Llogin Compiler running on http://localhost:${PORT}`);
  console.log(`   Max upload : ${MAX_FILE_MB}MB`);
  console.log(`   Timeout    : ${BUILD_TIMEOUT_MS / 1000}s`);
  console.log(`   Gradle     : ${GRADLE_CMD}\n`);
});
