'use strict';

const express    = require('express');
const multer     = require('multer');
const cors       = require('cors');
const rateLimit  = require('express-rate-limit');
const path       = require('path');
const fs         = require('fs');
const fsp        = require('fs').promises;
const { exec, spawn } = require('child_process');
const { v4: uuidv4 }  = require('uuid');

// ─── Config ──────────────────────────────────────────────────────────────────
const PORT             = process.env.PORT || 3000;
const MAX_FILE_MB      = parseInt(process.env.MAX_FILE_SIZE_MB  || '50');
const BUILD_TIMEOUT_MS = parseInt(process.env.BUILD_TIMEOUT_SECONDS || '300') * 1000;
const UPLOAD_DIR       = path.join(__dirname, 'uploads');
const OUTPUT_DIR       = path.join(__dirname, 'output');
const FRONTEND_DIR     = path.join(__dirname, 'public');
const GRADLE_CMD       = process.env.GRADLE_CMD || 'gradle';

// Ensure directories exist
[UPLOAD_DIR, OUTPUT_DIR, FRONTEND_DIR].forEach(d => fs.mkdirSync(d, { recursive: true }));

// ─── Job Store (in-memory) ────────────────────────────────────────────────────
// jobId -> { status, log, jarPath, startedAt, finishedAt, filename }
const jobs = new Map();

// Auto-clean jobs older than 1 hour
setInterval(() => {
  const cutoff = Date.now() - 3600_000;
  for (const [id, job] of jobs.entries()) {
    if (job.startedAt < cutoff) {
      // Clean up files
      if (job.workDir) fs.rmSync(job.workDir, { recursive: true, force: true });
      if (job.jarPath) fs.rmSync(job.jarPath, { force: true });
      jobs.delete(id);
    }
  }
}, 600_000);

// ─── Express Setup ────────────────────────────────────────────────────────────
const app = express();
app.use(cors());
app.use(express.json());

// Rate limiter: 10 builds per IP per hour
const buildLimiter = rateLimit({
  windowMs: 3600_000,
  max: 10,
  message: { error: 'Too many build requests from this IP. Try again in an hour.' }
});

// Static frontend
app.use(express.static(FRONTEND_DIR));

// ─── Multer Storage ──────────────────────────────────────────────────────────
const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, UPLOAD_DIR),
  filename:    (req, file, cb) => cb(null, `${uuidv4()}_${file.originalname}`)
});

const upload = multer({
  storage,
  limits: { fileSize: MAX_FILE_MB * 1024 * 1024 },
  fileFilter: (req, file, cb) => {
    if (!file.originalname.toLowerCase().endsWith('.zip')) {
      return cb(new Error('Only .zip files are allowed'));
    }
    cb(null, true);
  }
});

// ─── Routes ──────────────────────────────────────────────────────────────────

/** Health check */
app.get('/health', (req, res) => {
  res.json({ status: 'ok', jobs: jobs.size, uptime: process.uptime() });
});

/**
 * POST /api/build
 * Accepts a ZIP file, extracts it, runs `gradle shadowJar`, streams logs.
 */
app.post('/api/build', buildLimiter, upload.single('plugin'), async (req, res) => {
  if (!req.file) {
    return res.status(400).json({ error: 'No ZIP file uploaded.' });
  }

  const jobId   = uuidv4();
  const workDir = path.join(UPLOAD_DIR, jobId);
  const zipPath = req.file.path;

  // Register job immediately
  jobs.set(jobId, {
    status: 'extracting',
    log: [],
    jarPath: null,
    workDir,
    startedAt: Date.now(),
    finishedAt: null,
    filename: req.file.originalname
  });

  res.json({ jobId });

  // Run async build pipeline (non-blocking response already sent)
  runBuild(jobId, zipPath, workDir).catch(err => {
    const job = jobs.get(jobId);
    if (job) {
      job.status = 'failed';
      job.log.push(`[INTERNAL ERROR] ${err.message}`);
      job.finishedAt = Date.now();
    }
  });
});

/**
 * GET /api/status/:jobId
 * Returns current job status and streamed log lines.
 */
app.get('/api/status/:jobId', (req, res) => {
  const job = jobs.get(req.params.jobId);
  if (!job) return res.status(404).json({ error: 'Job not found.' });

  res.json({
    status:     job.status,
    log:        job.log,
    filename:   job.filename,
    startedAt:  job.startedAt,
    finishedAt: job.finishedAt,
    downloadUrl: job.jarPath ? `/api/download/${req.params.jobId}` : null
  });
});

/**
 * GET /api/download/:jobId
 * Streams the compiled JAR file for download.
 */
app.get('/api/download/:jobId', (req, res) => {
  const job = jobs.get(req.params.jobId);
  if (!job || !job.jarPath) return res.status(404).json({ error: 'JAR not available.' });
  if (!fs.existsSync(job.jarPath))  return res.status(410).json({ error: 'JAR file expired.' });

  const jarName = path.basename(job.jarPath);
  res.setHeader('Content-Disposition', `attachment; filename="${jarName}"`);
  res.setHeader('Content-Type', 'application/java-archive');
  fs.createReadStream(job.jarPath).pipe(res);
});

/**
 * GET /api/jobs
 * Lists all active jobs (for admin/debug).
 */
app.get('/api/jobs', (req, res) => {
  const list = [...jobs.entries()].map(([id, job]) => ({
    id,
    status: job.status,
    filename: job.filename,
    startedAt: job.startedAt,
    finishedAt: job.finishedAt
  }));
  res.json(list);
});

// ─── Build Pipeline ───────────────────────────────────────────────────────────

async function runBuild(jobId, zipPath, workDir) {
  const job = jobs.get(jobId);
  const log = (msg) => {
    console.log(`[${jobId.slice(0,8)}] ${msg}`);
    job.log.push(msg);
  };

  try {
    // ── Step 1: Extract ZIP ──────────────────────────────────────────────────
    log('📦 Extracting ZIP archive...');
    await extractZip(zipPath, workDir);
    log('✓ Extraction complete.');

    // ── Step 2: Find project root (look for build.gradle.kts or build.gradle) ─
    const projectRoot = await findProjectRoot(workDir);
    if (!projectRoot) throw new Error('Could not find build.gradle.kts or build.gradle in ZIP.');
    log(`✓ Project root detected: ${path.relative(workDir, projectRoot)}`);

    // ── Step 3: Validate build file ──────────────────────────────────────────
    const buildFile = fs.existsSync(path.join(projectRoot, 'build.gradle.kts'))
        ? 'build.gradle.kts' : 'build.gradle';
    log(`✓ Build file: ${buildFile}`);

    // ── Step 4: Generate Gradle wrapper if missing ───────────────────────────
    const gradlewPath = path.join(projectRoot, 'gradlew');
    if (!fs.existsSync(gradlewPath)) {
      log('⚙ Gradle wrapper not found. Generating wrapper...');
      await runCommand(`${GRADLE_CMD} wrapper --gradle-version 8.5`, projectRoot, log);
      log('✓ Wrapper generated.');
    }

    // Make gradlew executable
    await fsp.chmod(gradlewPath, 0o755);

    // ── Step 5: Run Gradle build ─────────────────────────────────────────────
    job.status = 'building';
    log('');
    log('🔨 Starting Gradle build (shadowJar)...');
    log('─'.repeat(50));

    await runGradle(projectRoot, log);

    log('─'.repeat(50));
    log('');

    // ── Step 6: Find output JAR ──────────────────────────────────────────────
    const jarFile = await findJar(projectRoot);
    if (!jarFile) throw new Error('Build succeeded but no JAR found in build/libs/.');

    log(`✓ JAR found: ${path.basename(jarFile)}`);

    // ── Step 7: Copy JAR to output directory ─────────────────────────────────
    const outputJar = path.join(OUTPUT_DIR, `${jobId}_${path.basename(jarFile)}`);
    await fsp.copyFile(jarFile, outputJar);

    // ── Step 8: Cleanup uploaded ZIP ─────────────────────────────────────────
    await fsp.rm(zipPath, { force: true });
    await fsp.rm(workDir, { recursive: true, force: true });

    job.jarPath    = outputJar;
    job.status     = 'success';
    job.finishedAt = Date.now();

    const elapsed = ((job.finishedAt - job.startedAt) / 1000).toFixed(1);
    log('');
    log(`✅ Build successful in ${elapsed}s! Download your plugin below.`);

  } catch (err) {
    job.status     = 'failed';
    job.finishedAt = Date.now();
    log('');
    log(`❌ Build failed: ${err.message}`);

    // Cleanup on failure
    await fsp.rm(zipPath, { force: true }).catch(() => {});
    await fsp.rm(workDir, { recursive: true, force: true }).catch(() => {});

    throw err;
  }
}

// ─── Helpers ──────────────────────────────────────────────────────────────────

function extractZip(zipPath, destDir) {
  return new Promise((resolve, reject) => {
    fs.mkdirSync(destDir, { recursive: true });
    exec(`unzip -q "${zipPath}" -d "${destDir}"`, (err, stdout, stderr) => {
      if (err) reject(new Error(`Extraction failed: ${stderr || err.message}`));
      else resolve();
    });
  });
}

async function findProjectRoot(baseDir) {
  // BFS search for build.gradle.kts or build.gradle
  const queue = [baseDir];
  while (queue.length > 0) {
    const dir = queue.shift();
    if (
      fs.existsSync(path.join(dir, 'build.gradle.kts')) ||
      fs.existsSync(path.join(dir, 'build.gradle'))
    ) {
      return dir;
    }
    // Add subdirectories (max depth 3)
    if (dir.split(path.sep).length - baseDir.split(path.sep).length < 3) {
      try {
        const entries = await fsp.readdir(dir, { withFileTypes: true });
        for (const e of entries) {
          if (e.isDirectory()) queue.push(path.join(dir, e.name));
        }
      } catch {}
    }
  }
  return null;
}

function runCommand(cmd, cwd, log) {
  return new Promise((resolve, reject) => {
    const proc = exec(cmd, { cwd, timeout: 60_000 });
    proc.stdout.on('data', d => d.toString().split('\n').filter(Boolean).forEach(l => log(l)));
    proc.stderr.on('data', d => d.toString().split('\n').filter(Boolean).forEach(l => log(`[WARN] ${l}`)));
    proc.on('close', code => code === 0 ? resolve() : reject(new Error(`Command failed with exit code ${code}`)));
  });
}

function runGradle(projectRoot, log) {
  return new Promise((resolve, reject) => {
    const gradlew = path.join(projectRoot, 'gradlew');
    const args = [
      'shadowJar',
      '--no-daemon',
      '--stacktrace',
      '--info',
      '-Dorg.gradle.jvmargs=-Xmx1g'
    ];

    const proc = spawn(gradlew, args, {
      cwd: projectRoot,
      env: { ...process.env, JAVA_HOME: process.env.JAVA_HOME || '/opt/java/openjdk' }
    });

    // Filter noisy Gradle output to only meaningful lines
    const importantPrefixes = [
      'Task :', '> Task', 'BUILD', 'FAILURE', 'SUCCESS',
      'error:', 'warning:', 'ERROR', 'Exception', 'Could not',
      '> Configure', 'Compiling', 'Processing', 'Copying',
      'e:', 'w:', 'note:', 'Deprecated'
    ];

    let buffer = '';

    const processOutput = (data, prefix = '') => {
      buffer += data.toString();
      const lines = buffer.split('\n');
      buffer = lines.pop() ?? '';
      for (const line of lines) {
        const trimmed = line.trim();
        if (!trimmed) continue;
        // Show important lines always, others can be filtered
        const isImportant = importantPrefixes.some(p => trimmed.includes(p));
        const isBuildLine = trimmed.startsWith('>') || trimmed.startsWith(':');
        if (isImportant || isBuildLine || trimmed.length < 200) {
          log(`${prefix}${trimmed}`);
        }
      }
    };

    proc.stdout.on('data', d => processOutput(d));
    proc.stderr.on('data', d => processOutput(d, '[ERR] '));

    const timeout = setTimeout(() => {
      proc.kill('SIGKILL');
      reject(new Error(`Build timed out after ${BUILD_TIMEOUT_MS / 1000}s`));
    }, BUILD_TIMEOUT_MS);

    proc.on('close', code => {
      clearTimeout(timeout);
      if (buffer.trim()) log(buffer.trim());
      if (code === 0) resolve();
      else reject(new Error(`Gradle exited with code ${code}. Check logs above.`));
    });

    proc.on('error', err => {
      clearTimeout(timeout);
      reject(new Error(`Failed to start Gradle: ${err.message}`));
    });
  });
}

async function findJar(projectRoot) {
  const libsDir = path.join(projectRoot, 'build', 'libs');
  if (!fs.existsSync(libsDir)) return null;

  const files = await fsp.readdir(libsDir);
  // Prefer non-plain JARs (shadowJar output won't have -plain suffix)
  const jars = files
    .filter(f => f.endsWith('.jar') && !f.endsWith('-plain.jar'))
    .map(f => path.join(libsDir, f));

  return jars.length > 0 ? jars[0] : null;
}

// ─── Start Server ─────────────────────────────────────────────────────────────
app.listen(PORT, () => {
  console.log(`\n🚀 Llogin Compiler running on http://localhost:${PORT}`);
  console.log(`   Max upload size : ${MAX_FILE_MB}MB`);
  console.log(`   Build timeout   : ${BUILD_TIMEOUT_MS / 1000}s`);
  console.log(`   Gradle command  : ${GRADLE_CMD}\n`);
});
